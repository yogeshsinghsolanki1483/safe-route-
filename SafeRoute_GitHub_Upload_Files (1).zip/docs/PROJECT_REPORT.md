# SafeRoute Project Report

## 1. Introduction
SafeRoute is a proposed smart travel-safety system intended to help travellers share journey information with trusted contacts and record safety check-ins. This repository contains a front-end demonstration of the main user interface and basic interactions.

## 2. Problem Identification
Travellers may find it difficult to keep trusted people updated during solo or long journeys. A simple system for recording journey details and preparing an emergency alert can make the process easier. This prototype demonstrates those basic interactions.

## 3. Objectives
- Allow a user to enter a destination and expected arrival time.
- Allow a user to maintain a list of trusted contacts.
- Provide a manual safety check-in.
- Demonstrate an SOS alert preparation flow.
- Provide a simple interface that can be extended into a full application.

## 4. Scope
The current version is a browser-based front-end demo. It uses local storage and does not connect to a server or send real notifications.

## 5. Software Requirements
- Modern web browser (Chrome, Edge, Firefox or Safari).
- HTML5, CSS3 and JavaScript.
- No additional installation is required to run the demo.

## 6. Functional Requirements
1. The user can enter a destination and ETA.
2. The user can start and end a journey.
3. The user can add and remove trusted contacts.
4. The user can record a manual safety check-in.
5. The user can preview an SOS alert.

## 7. Non-Functional Requirements
- Usable on desktop and mobile screen sizes.
- Clear and readable interface.
- Basic input validation through browser form controls.
- Demo data remains in the same browser using local storage.

## 8. Design Overview
The interface contains three main areas: journey details, emergency contacts and SOS. JavaScript handles user interactions and browser local storage. A future full system can add a backend and notification service.

## 9. Diagrams
Add your final Use Case, Activity, Sequence and DFD diagrams here. Ensure the diagrams match the implementation you submit.

## 10. Testing
Refer to `TEST_CASES.md`. Run each test in your browser and record the actual result and status before submitting.

## 11. Limitations
The current prototype does not provide real-time GPS tracking, SMS delivery, automated missed-check-in detection or emergency-service integration.

## 12. Conclusion
SafeRoute demonstrates a basic travel-safety interface and provides a starting point for a more complete system. Real-world use would require a secure backend, privacy safeguards and tested notification infrastructure.
