# SafeRoute – Test Cases

Run these tests in a browser. Record the actual result and mark Pass/Fail after testing.

| ID | Test scenario | Steps | Expected result |
|---|---|---|---|
| TC01 | Open application | Open `index.html` | Dashboard loads without errors |
| TC02 | Add contact | Enter a name and phone number, then select Add contact | Contact appears in the list |
| TC03 | Remove contact | Select Remove beside a saved contact | Contact disappears |
| TC04 | Start journey | Enter destination and ETA, then select Start journey | Status changes to Journey active |
| TC05 | Check-in while active | Start a journey and select I'm safe | Check-in time is displayed |
| TC06 | End journey | Start a journey and select End journey | Status changes to Not started |
| TC07 | SOS without active journey | Select SOS before starting a journey | App asks user to start a journey |
| TC08 | SOS during active journey | Start a journey and select SOS | Demo alert preview appears; no message is sent |
| TC09 | Local persistence | Add a contact and refresh the page | Contact remains in the same browser |
| TC10 | Responsive layout | Open on a narrow/mobile viewport | Sections stack and remain usable |

## Test execution record
| Test ID | Actual result | Pass/Fail | Date |
|---|---|---|---|
| TC01–TC10 | Fill after running each test | Fill after testing | Add date |
