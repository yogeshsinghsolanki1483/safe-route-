// SafeRoute front-end demo. Data is saved locally in this browser only.
const $ = (id) => document.getElementById(id);
let contacts = JSON.parse(localStorage.getItem('saferoute_contacts') || '[]');
let journey = JSON.parse(localStorage.getItem('saferoute_journey') || 'null');

function saveContacts(){ localStorage.setItem('saferoute_contacts', JSON.stringify(contacts)); }
function renderContacts(){
  const list = $('contactList'); list.innerHTML = '';
  if(!contacts.length){ list.innerHTML = '<li class="empty">No contacts added yet.</li>'; return; }
  contacts.forEach((c,index)=>{
    const li=document.createElement('li');
    const info=document.createElement('span'); info.textContent=c.name;
    const phone=document.createElement('small'); phone.textContent=c.phone; info.appendChild(phone);
    const remove=document.createElement('button'); remove.className='remove'; remove.textContent='Remove';
    remove.addEventListener('click',()=>{contacts.splice(index,1);saveContacts();renderContacts();});
    li.append(info,remove); list.appendChild(li);
  });
}
function renderJourney(){
  const active=journey && journey.active;
  $('journeyStatus').textContent=active?'Journey active':'Not started';
  $('journeyStatus').className='status '+(active?'active':'inactive');
  $('startButton').classList.toggle('hidden',!!active);
  $('endButton').classList.toggle('hidden',!active);
  $('checkinButton').disabled=!active;
  if(active){$('lastCheckin').textContent='Destination: '+journey.destination+' · ETA: '+new Date(journey.eta).toLocaleString();}
}
$('contactForm').addEventListener('submit',(e)=>{
  e.preventDefault();
  contacts.push({name:$('contactName').value.trim(),phone:$('contactPhone').value.trim()});
  saveContacts();renderContacts();e.target.reset();
});
$('journeyForm').addEventListener('submit',(e)=>{
  e.preventDefault();
  journey={destination:$('destination').value.trim(),eta:$('eta').value,active:true,startedAt:new Date().toISOString()};
  localStorage.setItem('saferoute_journey',JSON.stringify(journey));renderJourney();
});
$('endButton').addEventListener('click',()=>{
  journey.active=false;localStorage.setItem('saferoute_journey',JSON.stringify(journey));renderJourney();
  $('lastCheckin').textContent='Journey ended at '+new Date().toLocaleString()+'.';
});
$('checkinButton').addEventListener('click',()=>{
  $('lastCheckin').textContent='✓ You marked yourself safe at '+new Date().toLocaleTimeString()+'.';
  alert('Safety check-in recorded on this device.');
});
$('sosButton').addEventListener('click',()=>{
  if(!journey || !journey.active){alert('Please start a journey before using the SOS demo.');return;}
  const names=contacts.length?contacts.map(c=>c.name+' ('+c.phone+')').join('\n'):'No trusted contacts have been added.';
  alert('SOS DEMO — No message has been sent.\n\nEmergency alert prepared for:\n'+names+'\n\nDestination: '+journey.destination+'\nFor a real service, connect a secure backend and SMS/notification provider.');
});
renderContacts();renderJourney();
