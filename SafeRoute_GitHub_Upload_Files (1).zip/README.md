# SafeRoute – Smart Travel Safety and Emergency Alert System

SafeRoute is a student project prototype that demonstrates a simple travel-safety dashboard. A traveller can start a journey, add trusted contacts, record safety check-ins and preview an SOS alert.

## Features
- Start and end a journey with a destination and expected arrival time.
- Add and remove trusted emergency contacts.
- Record a manual "I'm safe" check-in.
- Preview an SOS alert for the saved contacts.
- Save demo information in browser local storage.

## Run the project
1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Add a destination and ETA, then click **Start journey**.
4. Add one or more trusted contacts.
5. Use **I'm safe** to record a check-in or **SOS** to preview the emergency alert.

No build tools or server are required for this front-end demo.

## Project structure
```text
SafeRoute-Travel-Safety-System/
├── index.html
├── style.css
├── script.js
├── README.md
├── docs/
│   ├── PROJECT_REPORT.md
│   └── TEST_CASES.md
└── .gitignore
```

## Important limitations
This repository is a front-end academic prototype, not a production emergency service. It does **not** send SMS, make phone calls, share live GPS location, monitor a user's movement, or automatically alert contacts after a missed check-in. The SOS action only displays a demo message in the browser. Do not rely on this prototype for personal safety or real emergencies.

A production version would require a secure backend, authentication, consent-based location permissions, reliable notification/SMS integration, server-side check-in timers, privacy controls and security testing.

## Suggested future improvements
- User registration and secure authentication.
- Consent-based live location sharing.
- Backend-managed journey and check-in records.
- SMS/push notifications through a verified provider.
- Automatic missed-check-in escalation with cancellation/grace period.
- Emergency contact verification and audit logs.

## Author
Add your name, college, course and guide details here.
